<div class="modal fade" data-bs-backdrop="static" id="addProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajout de nouveau profil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addProfileForm" action="{{ route('user.profiles.store') }}" method="POST">
                @csrf
                <div class="modal-body">@include('content.profiles._form_fields')</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary"><i class="icon-base ti tabler-device-floppy"></i> Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>